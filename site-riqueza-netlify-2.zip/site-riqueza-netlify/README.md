# Site Riqueza & Mentalidade — Pronto para Netlify

## Deploy no Netlify (3 formas)

### 1. Drag & drop (mais rápido)
1. Rode localmente: `npm install` e `npm run build`
2. Acesse https://app.netlify.com/drop
3. Arraste a pasta `dist/` gerada

### 2. Conectado ao Git
1. Suba este projeto no GitHub
2. No Netlify: **Add new site → Import from Git**
3. As configurações já estão no `netlify.toml`:
   - Build command: `npm run build`
   - Publish directory: `dist`

### 3. Netlify CLI
```bash
npm install
npm run build
npx netlify deploy --prod --dir=dist
```

## Rodar localmente
```bash
npm install
npm run dev
```

## Editar conteúdo
- Textos e links de afiliado: `src/App.tsx`
- Pop-up: `src/components/ExitIntentPopup.tsx`
- Cores e estilo: `src/index.css`
- Imagens: `src/assets/`
